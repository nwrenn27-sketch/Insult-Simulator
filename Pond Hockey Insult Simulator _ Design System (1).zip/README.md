# Pond Hockey Insult Simulator — Design System

## Overview

**Pond Hockey Insult Simulator** is a two-player local browser party game inspired by *Oh... Sir! The Insult Simulator*. Players choose from 8 hockey archetypes, then take turns assembling chirps from a shared word pool. Insults deal HP damage based on grammar quality and word composition. The last player standing wins the chirp-off.

The product is a **single-screen web game** — no backend, no build step, pure HTML/CSS/JS. The aesthetic is a full retro arcade/CRT experience: dark space backgrounds, neon glows, pixel fonts, scanline overlays, and pixel-art beveled borders on every interactive element.

---

## Sources

| Source | Path / URL |
|---|---|
| Local codebase (web game) | `Insult Generator/insult/web/` (mounted via File System Access API) |
| GitHub repo (same codebase, Rust CLI wrapper) | `https://github.com/nwrenn27-sketch/Insult-Simulator` (branch: `master`) |
| Local README | `Insult Generator/README.md` |

> **Note:** The GitHub repo's `web/` subfolder is byte-for-byte identical to the local mounted codebase. The Rust crate (`src/`) is a CLI wrapper; the web game lives entirely in `web/`.

---

## Products

| Surface | Description |
|---|---|
| **Web Game** | Single-page browser game. Two screens: Character Select → Game Screen. Overlay for Game Over. |

---

## Characters

| Name | # | Primary | Secondary | Eye |
|---|---|---|---|---|
| The Rookie | 97 | `#FF6600` | `#CC3300` | `#FFD700` |
| The Veteran | 2 | `#1A237E` | `#0D1257` | `#B8860B` |
| The Coach's Son | 1 | `#F9A825` | `#F57F17` | `#1565C0` |
| The Figure Skater | 10 | `#8E24AA` | `#6A0080` | `#E040FB` |
| The Beer Leaguer | 69 | `#2E7D32` | `#1B5E20` | `#A1887F` |
| The Goalie | 31 | `#0D1117` | `#1C2A1C` | `#00FFCC` |
| The European Import | 19 | `#D32F2F` | `#B71C1C` | `#1976D2` |
| The Ref | 0 | `#455A64` | `#263238` | `#FF6F00` |

---

## CONTENT FUNDAMENTALS

### Tone
**Aggressive, comedic, self-aware trash talk.** The game is built on chirping (hockey slang for trash talk). The writing never takes itself seriously — it's absurdist humor from a penalty box. Think British insult comedy meets pond hockey locker room.

### Voice
- Direct, punchy, loud
- Mixes hockey lingo with classic British-style insults ("you numpty!", "you pillock!", "cockwomble!")
- Character taglines are deadpan one-liners: *"Peaked at 17. Still out here though."*
- The game calls attacks "chirps", not "insults", on the game screen

### Casing
- **ALL CAPS** for every UI label, button, title, and heading
- Mixed case only for in-game insult text (the assembled chirp) and character taglines
- Labels use wide `letter-spacing` (2–5px) for that stamped/military feel

### Emoji
**None.** Zero emoji anywhere in the game. Unicode symbols used sparingly: `◄ ►` for navigation hints, `▶ ◀` for arrow buttons.

### Punctuation
Endings always include exclamation marks or question marks. Aggression is baked into the grammar. Examples:
- *"ya beauty!"*, *"you plug!"*, *"you duster!"*, *"ya donkey!"*
- *"and I have proof!"*, *"you cheeky bastard!"*, *"you tottering fool-born hedge-pig!"*

### Special labels
- `// CHIRP //` — labels the insult bubble (double-slash comment aesthetic)
- `◄ CHOOSE YOUR WORDS ►` — word bank label
- `PENALTY BOX` — stamped on the arena boards
- `K.O.!` — game over splash
- `WINS THE CHIRP-OFF` — win subtitle
- `RND` — round counter abbreviation

---

## VISUAL FOUNDATIONS

### Color Philosophy
**Dark neon arcade.** The entire game sits on near-black backgrounds with saturated neon accents in cyan, red, gold, green, and purple. There is zero white background use — white only appears as text or SVG stroke on characters.

### Color Roles
| Token | Hex | Usage |
|---|---|---|
| `--bg` | `#05070f` | Page/body background |
| `--panel` | `#080c1a` | Main game container |
| `--mid` | `#0c1228` | Intermediate panel depth |
| `--dim` | `#1c2840` | Borders, dividers |
| `--text` | `#c8dcf0` | Default body text |
| `--cyan` | `#00e5ff` | P1 accent, game border, neon trim |
| `--red` | `#ff2244` | P2 accent, damage numbers, K.O. |
| `--gold` | `#ffd700` | Titles, insult bubble, round counter |
| `--green` | `#00ff88` | Primary action buttons |
| `--purple` | `#cc44ff` | "And" word buttons, accent |

### Typography
Two Google Fonts, exclusively:
- **Press Start 2P** (`--px`) — 8-bit pixel font. Used for ALL UI labels, headings, button text, round counter. Typically 7–22px with `letter-spacing: 2–5px`.
- **VT323** (`--vt`) — monospace CRT terminal font. Used for insult text (36px), word buttons (22px), taglines. Body font for the game.

**No other typefaces are used anywhere.**

### Backgrounds
- Body: `#05070f` + subtle radial blue-tinted gradient at top (`rgba(0,80,180,0.07)`)
- Arena background: faint grid lines (repeating-linear-gradient at ~0.4–0.6% opacity)
- Character select: full-screen `#04060d` + CRT scanline overlay (repeating cyan at 1% opacity)
- **CRT scanlines**: `body::before` — fixed overlay with `repeating-linear-gradient` every 4px, `rgba(0,0,0,0.22)`. Z-index 9999, pointer-events none. Covers everything.

### Borders
- All borders are **square (border-radius: 0)** — no rounded corners anywhere in the game
- Primary container: `4px solid --cyan`, double-offset with `2px --bg` gap (creates "inset" look)
- Neon top trim: `linear-gradient(90deg, transparent, cyan, gold, cyan, transparent)` — 3px line
- Pixel-art **beveled** border on interactive elements: lighter top/left, darker right/bottom (3D press effect)

### Shadows & Glows
- Text shadows: `0 0 Xpx rgba(color, opacity)` — "neon bloom" effect on key text
- Box shadows: inner glow + outer glow layered. Example on game container: 4 shadow layers
- Health bar glow: `0 0 14px rgba(0,229,255,0.55)` (cyan for P1), `0 0 14px rgba(255,34,68,0.5)` (red for P2)
- Insult bubble: pulsing `bubbleGlow` keyframe animation (3s infinite ease-in-out)
- Damage number: `0 0 10px rgba(255,34,68,1)` + `0 0 30px rgba(255,34,68,0.7)` + hard `2px 2px 0` offset

### Animations
| Name | Usage | Style |
|---|---|---|
| `bubbleGlow` | Insult bubble | 3s infinite pulse, box-shadow intensity |
| `damagePopup` | Damage number | Scale bounce: 0→1.5→0.92→1, rotate -12→4→0 |
| `p1Attack` / `p2Attack` | Character attack | 0.5s ease, translate + rotate + scale(1.08) |
| `p1Hurt` / `p2Hurt` | Character hit | 0.45s ease, translate shake |
| `goEntrance` | Game-over box | 0.4s scale 0.8→1 |
| `koFlash` | K.O. text | 1s double-flash opacity |
| `csPopIn` | Character select sprite | 0.18s scale + translateY pop |

**Easing:** `ease` is the default. No spring or bounce physics. Transitions are fast (0.08–0.5s).

### Hover/Press States
- **Hover**: `filter: brightness(1.15–1.35)` + subtle lift `translateY(-2px)` on word buttons
- **Press (active)**: `translate(2px, 2px)` + inverted bevel (swap light/dark border sides) → feels physically pressed
- No color changes on hover — brightness filter only

### Penalty Box (arena)
- Metal pipe bars: `linear-gradient` from light silver to dark slate
- Frosted glass area: `rgba(100,180,255,0.07)` background + glare overlay
- Red hockey boards at bottom: `border-top: 6px solid #CC1010`
- "PENALTY BOX" stamped label in Press Start 2P, 7px, dark on white boards
- Breath fog effect: radial gradient oval, opacity transition on player action

### Cards & Containers
- **No rounded corners anywhere** (border-radius: 0 universally)
- Panels use `border: 3px solid rgba(color, 0.5)` + subtle outer glow box-shadow
- Character picker panels: P1 in cyan, P2 in red — color-coded throughout
- Background of panels: `#070c1a`, `inset 0 0 30px rgba(0,0,0,0.4)`

### Iconography
See ICONOGRAPHY section below.

### Color Vibe of Imagery
All characters are **SVG-drawn** (no raster images). Color palette per character uses their jersey primary/secondary + a skin tone (`#FFD4A3`). Outlines are `stroke: black, stroke-width: 2–2.5`. Drop shadows: `filter: drop-shadow()` with the player's accent color.

### Spacing
- The game uses a fluid layout (95vw × 95vh) — spacing is mostly `padding` and `gap` in flex contexts
- Typical padding: 10–24px for sections, 6–16px for buttons
- Gap between elements: 8–14px
- No formal spacing scale — organic, contextual

---

## VISUAL FOUNDATIONS — Word Button Color System

Word buttons have a distinct color per grammatical type:

| Type | Background | Text | Border highlight |
|---|---|---|---|
| Noun | `#00101e` | `#66ccff` | `#0088cc` |
| Verb | `#1a0008` | `#ff8899` | `#cc1a33` |
| Ending | `#140e00` | `#ffdd66` | `#bb8800` |
| And | `#120020` | `#dd88ff` | `#8822bb` |

---

## ICONOGRAPHY

### Approach
**No external icon library is used.** All visual "icons" are:
1. **Inline SVG hockey player sprites** — procedurally generated via `characters.js`. Each character is a 200×280 viewBox SVG with section-based builder functions (helmet, jersey, arms, face, etc). Colors come from the character's `primary`/`secondary`/`eyeColor` props.
2. **Unicode characters** as UI icons: `◄`, `►`, `▶`, `◀` for navigation arrows; used as text inside `<button>` elements.
3. **CSS pseudo-elements** with text content for labels (`// CHIRP //`, `◄ CHOOSE YOUR WORDS ►`).

### No raster images
Zero `.png`, `.jpg`, `.webp`, or `.gif` files in the entire project. Everything is code-drawn or text.

### Character SVG Builder
The `makeCharacterSVG(primary, secondary, eyeColor, number, mirrored, opts)` function in `characters.js` accepts per-character overrides for: helmet, mouth, rightArm, extras, scaleX. This allows dramatic visual differentiation while sharing the same base body SVG.

---

## File Index

```
README.md                    ← This file
SKILL.md                     ← Agent skill definition
colors_and_type.css          ← CSS custom properties: colors + typography
assets/                      ← (No raster assets; characters are SVG-generated)
preview/
  colors-bg-panel.html       ← Background/panel color swatches
  colors-neon.html           ← Neon accent colors
  colors-characters.html     ← Per-character jersey colors
  colors-semantic.html       ← Semantic color roles
  type-display.html          ← Press Start 2P specimens
  type-body.html             ← VT323 specimens
  type-scale.html            ← Full type scale in use
  components-buttons.html    ← Game buttons (primary + secondary)
  components-word-buttons.html ← Word type buttons (noun/verb/ending/and)
  components-health-bars.html  ← HP bars (full, mid, low)
  components-insult-bubble.html ← Chirp display bubble
  components-penalty-box.html  ← Penalty box arena frame
  components-game-over.html    ← K.O. overlay
  brand-characters.html        ← Full character roster sprites
  brand-crt-effect.html        ← CRT scanline + glow effect demo
ui_kits/
  game/
    README.md                ← UI kit notes
    index.html               ← Full interactive game prototype
    CharacterSelect.jsx      ← Character picker component
    GameScreen.jsx           ← Main game screen component
    GameOver.jsx             ← K.O. overlay component
    Shared.jsx               ← Shared primitives (tokens, buttons, etc.)
```
