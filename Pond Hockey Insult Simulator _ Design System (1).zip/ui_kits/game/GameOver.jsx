// GameOver.jsx — K.O. overlay
// Requires: React, GameButton, SecondaryButton (from Shared.jsx)

function GameOver({ winner, onRematch, onMenu }) {
  return (
    <div style={{
      position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.88)',
      display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 200,
    }}>
      <style>{`
        @keyframes goEntrance { from{transform:scale(0.8);opacity:0} to{transform:scale(1);opacity:1} }
        @keyframes koFlash { 0%,40%,60%,100%{opacity:1} 50%{opacity:0.2} 55%{opacity:1} 57%{opacity:0.2} }
        .go-box { animation: goEntrance 0.4s ease both; }
        .ko-text { animation: koFlash 1s ease 0.1s both; }
      `}</style>
      <div className="go-box" style={{
        background: '#03050d', border: '4px solid #ffd700',
        padding: '48px 64px', textAlign: 'center',
        display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 20,
        boxShadow: '0 0 60px rgba(255,215,0,0.25), 0 0 120px rgba(255,215,0,0.08), inset 0 0 40px rgba(0,0,0,0.6)',
      }}>
        <div className="ko-text" style={{
          fontFamily: "'Press Start 2P', monospace", fontSize: 42, color: '#ff2244',
          textShadow: '0 0 20px rgba(255,34,68,1), 0 0 50px rgba(255,34,68,0.6), 3px 3px 0 #330011',
          letterSpacing: 4,
        }}>K.O.!</div>
        <div style={{
          fontFamily: "'Press Start 2P', monospace", fontSize: 13, color: '#ffd700',
          letterSpacing: 3, textShadow: '0 0 16px rgba(255,215,0,0.9)', lineHeight: 1.6,
        }}>{winner}</div>
        <div style={{
          fontFamily: "'Press Start 2P', monospace", fontSize: 8, color: '#00e5ff',
          letterSpacing: 5, textShadow: '0 0 10px rgba(0,229,255,0.7)',
        }}>WINS THE CHIRP-OFF</div>
        <div style={{ display: 'flex', gap: 20, marginTop: 12 }}>
          <GameButton onClick={onRematch}>REMATCH</GameButton>
          <SecondaryButton onClick={onMenu}>MENU</SecondaryButton>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { GameOver });
