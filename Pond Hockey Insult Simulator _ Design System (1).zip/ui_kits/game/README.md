# UI Kit: Pond Hockey Insult Simulator — Web Game

High-fidelity interactive recreation of the full game. Cosmetic components only — no Rust, no build step.

## Screens

1. **Character Select** — 2-player picker with SVG sprites, carousel, dots, VS label
2. **Game Screen** — Health bars, penalty boxes, insult bubble, word pool, turn indicator
3. **Game Over Overlay** — K.O. splash, winner name, rematch/menu

## Files

| File | Contents |
|---|---|
| `index.html` | Entry point, loads all components via Babel |
| `Shared.jsx` | Tokens, `GameButton`, `SecondaryButton`, shared primitives |
| `CharacterSelect.jsx` | Full character select screen |
| `GameScreen.jsx` | Main game screen (health bars, pboxes, word pool, insult bubble) |
| `GameOver.jsx` | K.O. overlay |

## Design Notes

- All character sprites are SVG-generated (no rasters)
- CRT scanline overlay is always-on via `body::before`
- Fonts: Press Start 2P (display) + VT323 (body) from Google Fonts
- Border-radius: 0 everywhere — pixel aesthetic
- Color system matches `colors_and_type.css` exactly

## Running

Open `index.html` directly in a browser. No server needed (Babel transpiles inline).
