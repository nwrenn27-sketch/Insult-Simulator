// CharacterSelect.jsx — full character picker screen
// Requires: React, makeCharSVG, CHARACTERS, GameButton (from Shared.jsx)

function CharacterPicker({ player, charIdx, onPrev, onNext }) {
  const char = CHARACTERS[charIdx];
  const mirrored = player === 2;
  const accentColor = player === 1 ? '#00e5ff' : '#ff2244';
  const accentGlow  = player === 1 ? 'rgba(0,229,255,0.06)' : 'rgba(255,34,68,0.06)';
  const accentBorder= player === 1 ? 'rgba(0,229,255,0.5)'  : 'rgba(255,34,68,0.5)';

  const [animKey, setAnimKey] = React.useState(0);
  React.useEffect(() => { setAnimKey(k => k + 1); }, [charIdx]);

  return (
    <div style={{
      display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12,
      background: '#070c1a', padding: '20px 22px 14px', minWidth: 300,
      border: `3px solid ${accentBorder}`,
      boxShadow: `0 0 24px ${accentGlow}, inset 0 0 30px rgba(0,0,0,0.4)`,
    }}>
      <div style={{
        fontFamily: "'Press Start 2P', monospace", fontSize: 10, letterSpacing: 4,
        color: accentColor, textShadow: `0 0 12px ${accentColor}88`,
        textTransform: 'uppercase',
      }}>PLAYER {player}</div>
      <div style={{
        fontFamily: "'Press Start 2P', monospace", fontSize: 7, color: 'rgba(255,255,255,0.28)',
        letterSpacing: 2, textTransform: 'uppercase',
      }}>{player === 1 ? 'Keys: A / D' : 'Keys: ◄ / ►'}</div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
        <ArrowBtn onClick={onPrev}>&#9664;</ArrowBtn>
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8, minWidth: 200 }}>
          <style>{`@keyframes csPopIn{from{opacity:0;transform:scale(0.75) translateY(10px)}to{opacity:1;transform:scale(1) translateY(0)}}.cs-anim-${player}-${animKey}{animation:csPopIn 0.18s ease}`}</style>
          <div className={`cs-anim-${player}-${animKey}`} style={{ width: 180, height: 220, display: 'flex', alignItems: 'flex-end', justifyContent: 'center', filter: 'drop-shadow(0 8px 20px rgba(255,255,255,0.08))' }}
            dangerouslySetInnerHTML={{ __html: makeCharSVG(char.primary, char.secondary, char.eyeColor, char.number, mirrored, char.scaleX) }}
          />
          <div style={{ fontFamily: "'Press Start 2P', monospace", fontSize: 9, color: '#fff', textAlign: 'center', textTransform: 'uppercase', letterSpacing: 2, textShadow: '2px 2px 0 rgba(0,0,0,0.9)' }}>
            {char.name}
          </div>
          <div style={{ fontFamily: "'VT323', monospace", fontSize: 17, color: 'rgba(200,220,255,0.5)', textAlign: 'center', maxWidth: 190, lineHeight: 1.4 }}>
            {char.tagline}
          </div>
        </div>
        <ArrowBtn onClick={onNext}>&#9654;</ArrowBtn>
      </div>
      {/* Dots */}
      <div style={{ display: 'flex', gap: 8 }}>
        {CHARACTERS.map((_, i) => (
          <div key={i} style={{
            width: 8, height: 8, border: `2px solid ${i === charIdx ? '#ffd700' : 'rgba(255,255,255,0.2)'}`,
            background: i === charIdx ? '#ffd700' : 'rgba(255,255,255,0.12)',
            boxShadow: i === charIdx ? '0 0 8px rgba(255,215,0,0.8)' : 'none',
          }}/>
        ))}
      </div>
    </div>
  );
}

function ArrowBtn({ children, onClick }) {
  const [pressed, setPressed] = React.useState(false);
  const [hover, setHover]   = React.useState(false);
  return (
    <button onClick={onClick}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      onMouseDown={() => setPressed(true)} onMouseUp={() => setPressed(false)}
      style={{
        background: '#0a0d1c', color: hover ? '#ffd700' : '#c8dcf0',
        fontSize: 20, width: 48, height: 48, borderRadius: 0, cursor: 'pointer',
        display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
        borderTop:    `3px solid ${pressed ? '#0d1020' : '#2a3a54'}`,
        borderLeft:   `3px solid ${pressed ? '#0d1020' : '#2a3a54'}`,
        borderRight:  `3px solid ${pressed ? '#2a3a54' : '#0d1020'}`,
        borderBottom: `3px solid ${pressed ? '#2a3a54' : '#0d1020'}`,
        textShadow: hover ? '0 0 8px rgba(255,215,0,0.7)' : 'none',
        transform: pressed ? 'translate(2px,2px)' : 'none',
        filter: hover ? 'brightness(1.3)' : 'none',
        transition: 'filter 0.1s, transform 0.1s',
      }}>
      {children}
    </button>
  );
}

function CharacterSelect({ onStart }) {
  const [p1, setP1] = React.useState(0);
  const [p2, setP2] = React.useState(1);
  const n = CHARACTERS.length;

  React.useEffect(() => {
    const handler = (e) => {
      if (e.key === 'a' || e.key === 'A') setP1(i => (i - 1 + n) % n);
      if (e.key === 'd' || e.key === 'D') setP1(i => (i + 1) % n);
      if (e.key === 'ArrowLeft')  { e.preventDefault(); setP2(i => (i - 1 + n) % n); }
      if (e.key === 'ArrowRight') { e.preventDefault(); setP2(i => (i + 1) % n); }
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onStart(p1, p2); }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [p1, p2, onStart, n]);

  return (
    <div style={{
      position: 'fixed', inset: 0, display: 'flex', flexDirection: 'column',
      alignItems: 'center', justifyContent: 'center', gap: 26,
      background: '#04060d',
      backgroundImage: 'repeating-linear-gradient(0deg,transparent 0px,transparent 3px,rgba(0,229,255,0.01) 3px,rgba(0,229,255,0.01) 4px)',
      fontFamily: "'Press Start 2P', monospace", padding: 20, zIndex: 100,
    }}>
      <div style={{
        fontSize: 22, color: '#ffd700', textTransform: 'uppercase', letterSpacing: 4,
        textShadow: '0 0 20px rgba(255,215,0,0.85), 0 0 50px rgba(255,215,0,0.35), 3px 3px 0 rgba(0,0,0,0.95)',
      }}>CHOOSE YOUR FIGHTERS</div>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 36, width: '100%', maxWidth: 1000 }}>
        <CharacterPicker player={1} charIdx={p1} onPrev={() => setP1(i => (i-1+n)%n)} onNext={() => setP1(i => (i+1)%n)} />
        <div style={{ fontSize: 32, color: '#ffd700', textShadow: '0 0 20px rgba(255,215,0,0.9), 0 0 50px rgba(255,215,0,0.4), 3px 3px 0 rgba(0,0,0,0.95)', letterSpacing: 4, userSelect: 'none', flexShrink: 0 }}>VS</div>
        <CharacterPicker player={2} charIdx={p2} onPrev={() => setP2(i => (i-1+n)%n)} onNext={() => setP2(i => (i+1)%n)} />
      </div>
      <GameButton size="lg" onClick={() => onStart(p1, p2)}>START GAME</GameButton>
    </div>
  );
}

Object.assign(window, { CharacterSelect });
