// GameScreen.jsx — main game screen
// Requires: React, makeCharSVG, CHARACTERS, WORDS, GameButton, SecondaryButton

// ── Word logic ──────────────────────────────────────────────────────────────
const rand = n => Math.floor(Math.random() * n);
const pick = arr => arr[rand(arr.length)];
function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) { const j = rand(i+1); [a[i],a[j]] = [a[j],a[i]]; }
  return a;
}

function generatePool() {
  const nc = 3 + rand(3), vc = 3 + rand(3), left = 13 - nc - vc;
  const nouns   = shuffle(WORDS.nouns).slice(0,nc).map(([s,t]) => ({type:'noun',  singular:s, text:t}));
  const verbs   = shuffle(WORDS.verbs).slice(0,vc).map(([n,t]) => ({type:'verb',  needsNoun:n,text:t}));
  const extras  = Array.from({length:left}, () =>
    rand(4) === 0 ? {type:'ending', text:pick(WORDS.endings)[1]} : {type:'and'});
  return shuffle([...nouns,...verbs,...extras]);
}

function verbText(w, singular) {
  let t = w.text;
  if (singular) return t.replace(/\[is\/are\]/g,'is').replace(/\[was\/were\]/g,'was').replace(/\[has\/have\]/g,'has').replace(/\(s\)/g,'s');
  return t.replace(/\[is\/are\]/g,'are').replace(/\[was\/were\]/g,'were').replace(/\[has\/have\]/g,'have').replace(/\(s\)/g,'');
}

function wordDisplay(w, singular = false) {
  if (w.type === 'noun')   return w.text;
  if (w.type === 'verb')   return verbText(w, singular);
  if (w.type === 'ending') return w.text;
  if (w.type === 'and')    return 'and';
  return '';
}

function formatInsult(sel) {
  let result = '', singular = false;
  sel.forEach((w, i) => {
    if (w.type === 'ending') result += ',';
    if (i > 0) result += ' ';
    if (w.type === 'noun') { singular = w.singular; result += w.text; }
    else result += wordDisplay(w, singular);
  });
  const last = sel[sel.length - 1];
  if (last && last.type !== 'ending') result += '!';
  return result;
}

function calcDmg(sel) {
  let d = 5 + sel.length * 2;
  if (sel.some(w=>w.type==='noun') && sel.some(w=>w.type==='verb')) d += 10;
  if (sel.some(w=>w.type==='ending')) d += 5;
  d += rand(10);
  return Math.max(5, Math.min(40, d));
}

// ── PenaltyBox ───────────────────────────────────────────────────────────────
function PenaltyBox({ char, mirrored, fogActive, animClass }) {
  const svgHtml = makeCharSVG(char.primary, char.secondary, char.eyeColor, char.number, mirrored, char.scaleX);
  return (
    <div style={{ display:'flex', flexDirection:'column', background:'#07101e', border:'6px solid #4a6070', boxShadow:'0 0 0 2px #090c12,0 0 30px rgba(0,0,0,0.9),inset 0 0 20px rgba(0,0,0,0.6)', overflow:'hidden', flex:1, maxWidth:280, minWidth:180 }}>
      <div style={{ height:12, flexShrink:0, background:'linear-gradient(180deg,#c8d8e8 0%,#88a0b4 30%,#3a5060 60%,#7898b0 100%)', borderTop:'1px solid #ddeeff', borderBottom:'1px solid #182838' }}/>
      <div style={{ position:'relative', flex:1, display:'flex', alignItems:'flex-end', justifyContent:'center', background:'linear-gradient(180deg,rgba(100,180,255,0.07) 0%,rgba(80,150,240,0.02) 100%)', overflow:'hidden', minHeight:260 }}>
        <div style={{ position:'absolute', top:8, left:10, width:'26%', height:'52%', background:'linear-gradient(140deg,rgba(255,255,255,0.14) 0%,rgba(255,255,255,0.04) 50%,transparent 100%)', borderRadius:'40% 60% 70% 30%/40% 50% 60% 50%', pointerEvents:'none', zIndex:11 }}/>
        {fogActive && <div style={{ position:'absolute', bottom:115, [mirrored?'left':'right']:-4, width:75, height:48, background:'radial-gradient(ellipse,rgba(255,255,255,0.13) 0%,rgba(255,255,255,0.04) 55%,transparent 70%)', pointerEvents:'none', zIndex:12 }}/>}
        <style>{`
          @keyframes p1Attack{0%{transform:translateX(16px) rotate(5deg)}40%{transform:translateX(44px) rotate(13deg) scale(1.08)}100%{transform:translateX(16px) rotate(5deg)}}
          @keyframes p2Attack{0%{transform:translateX(-16px) rotate(-5deg)}40%{transform:translateX(-44px) rotate(-13deg) scale(1.08)}100%{transform:translateX(-16px) rotate(-5deg)}}
          @keyframes p1Hurt{0%,100%{transform:translateX(16px) rotate(5deg)}30%{transform:translateX(-8px) rotate(0deg)}65%{transform:translateX(26px) rotate(8deg)}}
          @keyframes p2Hurt{0%,100%{transform:translateX(-16px) rotate(-5deg)}30%{transform:translateX(8px) rotate(0deg)}65%{transform:translateX(-26px) rotate(-8deg)}}
        `}</style>
        <div className={animClass} style={{ width:200, height:280, filter:`drop-shadow(0 10px 24px ${mirrored ? 'rgba(255,34,68,0.22)' : 'rgba(0,229,255,0.22)'})`}}
          dangerouslySetInnerHTML={{ __html: svgHtml }}/>
      </div>
      <div style={{ height:12, flexShrink:0, background:'linear-gradient(180deg,#c8d8e8 0%,#88a0b4 30%,#3a5060 60%,#7898b0 100%)', borderTop:'1px solid #ddeeff', borderBottom:'1px solid #182838' }}/>
      <div style={{ flexShrink:0, background:'linear-gradient(180deg,#eee 0%,#ddd 100%)', borderTop:'6px solid #CC1010', borderBottom:'3px solid #CC1010', padding:'8px 16px', textAlign:'center', position:'relative' }}>
        <div style={{ position:'absolute', bottom:5, left:0, right:0, height:2, background:'#CC1010' }}/>
        <span style={{ fontFamily:"'Press Start 2P',monospace", fontSize:7, fontWeight:'bold', letterSpacing:3, color:'#333', textTransform:'uppercase' }}>PENALTY BOX</span>
      </div>
    </div>
  );
}

// ── HealthBar ────────────────────────────────────────────────────────────────
function HealthBar({ hp, player }) {
  const isP2 = player === 2;
  const seg = 'repeating-linear-gradient(90deg,transparent,transparent 9px,rgba(0,0,0,0.35) 9px,rgba(0,0,0,0.35) 10px)';
  let barBg, glow;
  if (hp > 60) {
    barBg = isP2 ? `${seg},linear-gradient(90deg,#ff6680 0%,#ff2244 100%)` : `${seg},linear-gradient(90deg,#66eeff 0%,#00bbdd 100%)`;
    glow  = isP2 ? '0 0 14px rgba(255,34,68,0.5)' : '0 0 14px rgba(0,229,255,0.55)';
  } else if (hp > 30) {
    barBg = `${seg},linear-gradient(90deg,#ffdd44 0%,#ffaa00 100%)`;
    glow  = '0 0 14px rgba(255,180,0,0.55)';
  } else {
    barBg = `${seg},linear-gradient(90deg,#ff8888 0%,#ff2244 100%)`;
    glow  = '0 0 18px rgba(255,34,68,0.7)';
  }
  return (
    <div style={{ background:'#080a14', padding:4, border:'2px solid #1c2840', boxShadow:'inset 0 0 12px rgba(0,0,0,0.8)', minWidth:260 }}>
      <div style={{ height:22, width: hp+'%', backgroundImage:barBg, boxShadow:glow, transition:'width 0.4s ease' }}/>
    </div>
  );
}

// ── WordButton ───────────────────────────────────────────────────────────────
function WordButton({ word, onClick }) {
  const [pressed, setPressed] = React.useState(false);
  const [hover, setHover] = React.useState(false);
  const types = {
    noun:   { bg:'#00101e', color:'#66ccff', hi:'#0088cc', lo:'#003a55', ts:'0 0 8px rgba(0,160,255,0.5)' },
    verb:   { bg:'#1a0008', color:'#ff8899', hi:'#cc1a33', lo:'#550011', ts:'0 0 8px rgba(255,80,110,0.5)' },
    ending: { bg:'#140e00', color:'#ffdd66', hi:'#bb8800', lo:'#553d00', ts:'0 0 8px rgba(255,200,0,0.5)' },
    and:    { bg:'#120020', color:'#dd88ff', hi:'#8822bb', lo:'#3d0055', ts:'0 0 8px rgba(190,80,255,0.5)' },
  };
  const t = types[word.type] || types.and;
  const label = word.type === 'noun' ? word.text : word.type === 'verb' ? verbText(word, false) : word.type === 'ending' ? word.text : 'and';
  return (
    <button onClick={onClick}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      onMouseDown={() => setPressed(true)} onMouseUp={() => setPressed(false)}
      style={{
        fontFamily:"'VT323',monospace", fontSize:22, lineHeight:1,
        background:t.bg, padding:'6px 16px', color:t.color, cursor:'pointer',
        borderRadius:0, textTransform:'uppercase', letterSpacing:1,
        borderTop:   `3px solid ${pressed ? t.lo : t.hi}`,
        borderLeft:  `3px solid ${pressed ? t.lo : t.hi}`,
        borderRight: `3px solid ${pressed ? t.hi : t.lo}`,
        borderBottom:`3px solid ${pressed ? t.hi : t.lo}`,
        textShadow:t.ts,
        filter: hover && !pressed ? 'brightness(1.35)' : 'none',
        transform: hover && !pressed ? 'translateY(-2px)' : pressed ? 'translate(2px,2px)' : 'none',
        transition:'filter 0.08s,transform 0.08s',
      }}>
      {label}
    </button>
  );
}

// ── GameScreen ───────────────────────────────────────────────────────────────
function GameScreen({ p1CharIdx, p2CharIdx, onMenu }) {
  const char1 = CHARACTERS[p1CharIdx];
  const char2 = CHARACTERS[p2CharIdx];

  const initState = () => ({
    currentPlayer: 1, round: 1,
    hp: { 1: 100, 2: 100 },
    pool: generatePool(), selected: [],
    animClass1: '', animClass2: '',
    fog1: false, fog2: false,
    damageText: '', showDamage: false,
  });

  const [gs, setGs] = React.useReducer((s, a) => ({...s, ...a}), null, initState);
  const [gameOver, setGameOver] = React.useState(null);

  const selectWord = (idx) => {
    setGs(s => {
      const pool = [...s.pool];
      const [word] = pool.splice(idx, 1);
      const selected = [...s.selected, word];
      const fog = { [`fog${s.currentPlayer}`]: true };
      setTimeout(() => setGs({ [`fog${s.currentPlayer}`]: false }), 900);
      return { pool, selected, ...fog };
    });
  };

  const fireInsult = () => {
    setGs(s => {
      if (!s.selected.length) return s;
      const attacker = s.currentPlayer, defender = attacker === 1 ? 2 : 1;
      const dmg = calcDmg(s.selected);
      const text = formatInsult(s.selected);
      const newHp = Math.max(0, s.hp[defender] - dmg);
      const animClass = `p${attacker}Attack`;
      const hurtClass = `p${defender}Hurt`;

      setTimeout(() => {
        setGs({ [`animClass${attacker}`]: '', [`animClass${defender}`]: '' });
        if (newHp <= 0) {
          setTimeout(() => setGameOver(char1.name === s.players?.[attacker]?.name ? char1.name : attacker === 1 ? char1.name : char2.name), 300);
        } else {
          setTimeout(() => setGs(s2 => ({
            currentPlayer: s2.currentPlayer === 1 ? 2 : 1,
            round: s2.currentPlayer === 2 ? s2.round + 1 : s2.round,
            pool: generatePool(), selected: [], showDamage: false,
          })), 2500);
        }
      }, 500);

      return {
        hp: {...s.hp, [defender]: newHp},
        [`animClass${attacker}`]: animClass,
        [`animClass${defender}`]: hurtClass,
        damageText: `-${dmg} HP`, showDamage: true,
        insultText: text,
      };
    });
  };

  const resetSel = () => setGs(s => ({ pool: generatePool(), selected: [] }));

  const insultText = gs.insultText && gs.selected.length === 0
    ? gs.insultText
    : gs.selected.length > 0
      ? formatInsult(gs.selected).replace(/!$/, '...').replace(/,\s/g, ', ')
      : 'Select words to build your insult!';

  const winnerName = gameOver || (gs.hp[1] <= 0 ? char2.name : gs.hp[2] <= 0 ? char1.name : null);

  return (
    <>
      {winnerName && <GameOver winner={winnerName} onRematch={() => { setGs(initState()); setGameOver(null); }} onMenu={onMenu} />}
      <style>{`
        @keyframes damagePopup{0%{transform:scale(0) rotate(-12deg);opacity:0}45%{transform:scale(1.5) rotate(4deg);opacity:1}65%{transform:scale(0.92) rotate(-1deg)}100%{transform:scale(1) rotate(0);opacity:1}}
        @keyframes bubbleGlow{0%,100%{box-shadow:0 0 16px rgba(255,215,0,0.18),0 0 50px rgba(255,215,0,0.04),inset 0 0 20px rgba(0,0,0,0.5)}50%{box-shadow:0 0 28px rgba(255,215,0,0.30),0 0 70px rgba(255,215,0,0.08),inset 0 0 20px rgba(0,0,0,0.5)}}
        .bubble-anim{animation:bubbleGlow 3s ease-in-out infinite}
        .p1Attack{animation:p1Attack 0.5s ease!important}.p2Attack{animation:p2Attack 0.5s ease!important}
        .p1Hurt{animation:p1Hurt 0.45s ease!important}.p2Hurt{animation:p2Hurt 0.45s ease!important}
        @keyframes p1Attack{0%{transform:translateX(16px) rotate(5deg)}40%{transform:translateX(44px) rotate(13deg) scale(1.08)}100%{transform:translateX(16px) rotate(5deg)}}
        @keyframes p2Attack{0%{transform:translateX(-16px) rotate(-5deg)}40%{transform:translateX(-44px) rotate(-13deg) scale(1.08)}100%{transform:translateX(-16px) rotate(-5deg)}}
        @keyframes p1Hurt{0%,100%{transform:translateX(16px) rotate(5deg)}30%{transform:translateX(-8px) rotate(0deg)}65%{transform:translateX(26px) rotate(8deg)}}
        @keyframes p2Hurt{0%,100%{transform:translateX(-16px) rotate(-5deg)}30%{transform:translateX(8px) rotate(0deg)}65%{transform:translateX(-26px) rotate(-8deg)}}
      `}</style>

      <div style={{ width:'95vw', maxWidth:1400, height:'95vh', background:'#080c1a', border:'4px solid #00e5ff', boxShadow:'0 0 0 2px #05070f,0 0 50px rgba(0,229,255,0.12),0 0 100px rgba(0,0,0,0.9),inset 0 0 60px rgba(0,0,0,0.5)', display:'flex', flexDirection:'column', position:'relative', overflow:'hidden' }}>
        {/* Neon top trim */}
        <div style={{ position:'absolute', top:0, left:0, right:0, height:3, background:'linear-gradient(90deg,transparent,#00e5ff,#ffd700,#00e5ff,transparent)', zIndex:20 }}/>

        {/* Health bars */}
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', padding:'10px 24px', background:'#03050c', borderBottom:'3px solid #1c2840', position:'relative', zIndex:10 }}>
          <div style={{ display:'flex', flexDirection:'column', gap:5, minWidth:280 }}>
            <div style={{ fontFamily:"'Press Start 2P',monospace", fontSize:8, color:'#00e5ff', textTransform:'uppercase', letterSpacing:2, textShadow:'0 0 10px rgba(0,229,255,0.7)' }}>{char1.name}</div>
            <HealthBar hp={gs.hp[1]} player={1}/>
          </div>
          <div style={{ fontFamily:"'Press Start 2P',monospace", fontSize:10, color:'#ffd700', background:'#03050c', padding:'8px 18px', border:'2px solid #ffd700', letterSpacing:2, whiteSpace:'nowrap', textShadow:'0 0 10px rgba(255,215,0,0.8)', boxShadow:'0 0 14px rgba(255,215,0,0.12),inset 0 0 10px rgba(0,0,0,0.5)' }}>
            RND <span style={{ color:'#ffd700' }}>{gs.round}</span>
          </div>
          <div style={{ display:'flex', flexDirection:'column', gap:5, minWidth:280, alignItems:'flex-end' }}>
            <div style={{ fontFamily:"'Press Start 2P',monospace", fontSize:8, color:'#ff2244', textTransform:'uppercase', letterSpacing:2, textShadow:'0 0 10px rgba(255,34,68,0.7)' }}>{char2.name}</div>
            <HealthBar hp={gs.hp[2]} player={2}/>
          </div>
        </div>

        {/* Game area */}
        <div style={{ flex:1, display:'flex', flexDirection:'column', overflow:'hidden', zIndex:1 }}>
          {/* Characters arena */}
          <div style={{ flex:1, display:'flex', justifyContent:'space-between', alignItems:'stretch', padding:'14px 20px', gap:12, background:'repeating-linear-gradient(0deg,transparent 0px,transparent 40px,rgba(255,255,255,0.006) 40px,rgba(255,255,255,0.006) 41px),repeating-linear-gradient(90deg,transparent 0px,transparent 80px,rgba(255,255,255,0.004) 80px,rgba(255,255,255,0.004) 81px),linear-gradient(180deg,#040810 0%,#060c1a 100%)' }}>
            <PenaltyBox char={char1} mirrored={false} fogActive={gs.fog1} animClass={gs.animClass1}/>
            {/* Center */}
            <div style={{ flex:1, display:'flex', flexDirection:'column', justifyContent:'center', alignItems:'center', gap:14, maxWidth:540 }}>
              {/* Insult bubble */}
              <div className="bubble-anim" style={{ background:'#03050d', border:'4px solid #ffd700', padding:'22px 26px 18px', minHeight:130, width:'100%', position:'relative' }}>
                <div style={{ position:'absolute', top:-13, left:18, fontFamily:"'Press Start 2P',monospace", fontSize:7, color:'#ffd700', background:'#03050d', padding:'2px 8px', textShadow:'0 0 8px rgba(255,215,0,0.8)', letterSpacing:3 }}>// CHIRP //</div>
                <div style={{ fontFamily:"'VT323',monospace", fontSize:32, fontWeight:'normal', textAlign:'center', color:'#fff', lineHeight:1.3, textShadow:'0 0 16px rgba(255,255,255,0.25)', textTransform:'uppercase', letterSpacing:1 }}>
                  {insultText}
                </div>
              </div>
              {/* Damage */}
              <div style={{ minHeight:50, display:'flex', alignItems:'center', justifyContent:'center' }}>
                {gs.showDamage && (
                  <div style={{ fontFamily:"'Press Start 2P',monospace", fontSize:28, color:'#ff2244', textShadow:'0 0 10px rgba(255,34,68,1),0 0 30px rgba(255,34,68,0.7),2px 2px 0 #330011', animation:'damagePopup 1s ease both' }}>
                    {gs.damageText}
                  </div>
                )}
              </div>
            </div>
            <PenaltyBox char={char2} mirrored={true} fogActive={gs.fog2} animClass={gs.animClass2}/>
          </div>

          {/* Word selection */}
          <div style={{ background:'#04060f', padding:'10px 18px 14px', borderTop:'3px solid #1c2840', display:'flex', flexDirection:'column', gap:10, position:'relative', zIndex:10 }}>
            <div style={{ fontFamily:"'Press Start 2P',monospace", fontSize:7, color:'rgba(0,229,255,0.4)', letterSpacing:3, textAlign:'center' }}>◄ CHOOSE YOUR WORDS ►</div>
            <div style={{ display:'flex', flexWrap:'wrap', gap:8, justifyContent:'center', minHeight:95, alignContent:'flex-start' }}>
              {gs.pool.map((w, i) => <WordButton key={i} word={w} onClick={() => selectWord(i)}/>)}
            </div>
            <div style={{ display:'flex', gap:16, justifyContent:'center' }}>
              <GameButton onClick={fireInsult}>Fire!</GameButton>
              <SecondaryButton onClick={resetSel}>Reset</SecondaryButton>
            </div>
          </div>
        </div>

        {/* Turn indicator */}
        <div style={{ background:'#03050c', padding:9, textAlign:'center', fontFamily:"'Press Start 2P',monospace", fontSize:8, color:'#c8dcf0', borderTop:'3px solid #1c2840', letterSpacing:3, textTransform:'uppercase' }}>
          <span style={{ color:'#ffd700', textShadow:'0 0 10px rgba(255,215,0,0.9)' }}>{gs.currentPlayer === 1 ? char1.name : char2.name}</span>'S TURN TO CHIRP
        </div>
      </div>
    </>
  );
}

Object.assign(window, { GameScreen });
