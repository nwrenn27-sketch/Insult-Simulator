// Shared.jsx — tokens, primitives, SVG builder, character data
// Exports to window: { GameButton, SecondaryButton, makeCharSVG, CHARACTERS, WORDS }

const FONTS = `@import url('https://fonts.googleapis.com/css2?family=Press+Start+2P&family=VT323&display=swap');`;

// ─── Character SVG Builder ───────────────────────────────────────────────────
function makeCharSVG(p, s, e, num, mirrored = false, scaleX = 1) {
  const body = `
  <ellipse cx="100" cy="277" rx="56" ry="8" fill="rgba(0,0,0,0.25)"/>
  <ellipse cx="48" cy="274" rx="14" ry="5" fill="#222" stroke="black" stroke-width="1.5"/>
  <path d="M 56 250 L 55 264 Q 55 271 63 271 L 89 271 Q 96 271 94 264 L 92 250 Z" fill="#e8e8e8" stroke="black" stroke-width="2.5"/>
  <rect x="52" y="269" width="46" height="6" rx="3" fill="#aaa" stroke="black" stroke-width="1.5"/>
  <path d="M 108 250 L 107 264 Q 107 271 115 271 L 141 271 Q 148 271 146 264 L 144 250 Z" fill="#e8e8e8" stroke="black" stroke-width="2.5"/>
  <rect x="106" y="269" width="46" height="6" rx="3" fill="#aaa" stroke="black" stroke-width="1.5"/>
  <path d="M 61 253 Q 73 251 87 253 M 61 258 Q 73 256 87 258" stroke="#444" stroke-width="1.5" fill="none"/>
  <path d="M 114 253 Q 126 251 140 253 M 114 258 Q 126 256 140 258" stroke="#444" stroke-width="1.5" fill="none"/>
  <path d="M 60 200 Q 56 225 56 250 L 93 250 Q 93 225 95 200 Z" fill="#1a1a30" stroke="black" stroke-width="2.5"/>
  <rect x="59" y="216" width="32" height="32" rx="8" fill="#2c3e50" stroke="black" stroke-width="2"/>
  <rect x="63" y="220" width="24" height="24" rx="5" fill="#3a5070"/>
  <path d="M 105 200 Q 107 225 107 250 L 144 250 Q 144 225 140 200 Z" fill="#1a1a30" stroke="black" stroke-width="2.5"/>
  <rect x="109" y="216" width="32" height="32" rx="8" fill="#2c3e50" stroke="black" stroke-width="2"/>
  <rect x="113" y="220" width="24" height="24" rx="5" fill="#3a5070"/>
  <line x1="22" y1="195" x2="38" y2="265" stroke="#9B7820" stroke-width="9" stroke-linecap="round"/>
  <line x1="21" y1="195" x2="27" y2="218" stroke="#111" stroke-width="10" stroke-linecap="round" opacity="0.8"/>
  <path d="M 34 261 Q 28 273 68 275 Q 75 266 68 260 Q 50 257 34 261 Z" fill="#111" stroke="black" stroke-width="2"/>
  <ellipse cx="50" cy="126" rx="30" ry="22" fill="${p}" stroke="black" stroke-width="2"/>
  <ellipse cx="150" cy="126" rx="30" ry="22" fill="${p}" stroke="black" stroke-width="2"/>
  <path d="M 38 120 Q 32 162 56 200 L 144 200 Q 168 162 162 120 Q 136 103 100 101 Q 64 103 38 120 Z" fill="white" stroke="black" stroke-width="2.5"/>
  <path d="M 38 120 Q 64 103 100 101 Q 136 103 162 120 Q 144 141 100 143 Q 56 141 38 120 Z" fill="${p}" stroke="black" stroke-width="2"/>
  <path d="M 40 165 Q 100 161 160 165 L 158 174 Q 100 170 42 174 Z" fill="${p}" stroke="black" stroke-width="1.5"/>
  <path d="M 40 124 Q 20 148 16 186" stroke="${p}" stroke-width="28" fill="none" stroke-linecap="round"/>
  <ellipse cx="17" cy="197" rx="26" ry="23" fill="${p}" stroke="black" stroke-width="2.5"/>
  <path d="M -6 183 Q -6 172 5 170 L 28 170 Q 40 172 40 183 L 40 193 Q 40 198 28 199 L 5 199 Q -6 198 -6 193 Z" fill="${s}" stroke="black" stroke-width="2"/>
  <path d="M 160 124 Q 180 148 184 174" stroke="${p}" stroke-width="28" fill="none" stroke-linecap="round"/>
  <ellipse cx="183" cy="185" rx="26" ry="23" fill="${p}" stroke="black" stroke-width="2.5"/>
  <path d="M 160 171 Q 160 160 171 158 L 194 158 Q 206 160 206 171 L 206 181 Q 206 186 194 187 L 171 187 Q 160 186 160 181 Z" fill="${s}" stroke="black" stroke-width="2"/>
  <rect x="88" y="107" width="24" height="18" rx="6" fill="#FFD4A3" stroke="black" stroke-width="2"/>
  <ellipse cx="100" cy="76" rx="38" ry="42" fill="#FFD4A3" stroke="black" stroke-width="2.5"/>
  <ellipse cx="62" cy="78" rx="10" ry="13" fill="#FFD4A3" stroke="black" stroke-width="2"/>
  <ellipse cx="138" cy="78" rx="10" ry="13" fill="#FFD4A3" stroke="black" stroke-width="2"/>
  <ellipse cx="79" cy="97" rx="14" ry="9" fill="#FF8877" opacity="0.45"/>
  <ellipse cx="121" cy="97" rx="14" ry="9" fill="#FF8877" opacity="0.45"/>
  <path d="M 62 80 Q 61 26 100 23 Q 139 26 138 80 Z" fill="${p}" stroke="black" stroke-width="2.5"/>
  <path d="M 74 31 Q 100 25 126 33" stroke="rgba(255,255,255,0.3)" stroke-width="7" fill="none" stroke-linecap="round"/>
  <ellipse cx="63" cy="77" rx="12" ry="16" fill="${s}" stroke="black" stroke-width="2"/>
  <ellipse cx="137" cy="77" rx="12" ry="16" fill="${s}" stroke="black" stroke-width="2"/>
  <path d="M 62 80 Q 100 86 138 80" stroke="black" stroke-width="2.5" fill="none"/>
  <path d="M 64 80 Q 100 87 136 80 L 134 91 Q 100 97 66 91 Z" fill="rgba(140,200,255,0.35)" stroke="black" stroke-width="2"/>
  <path d="M 78 89 Q 88 83 97 89" stroke="black" stroke-width="5" fill="none" stroke-linecap="round"/>
  <path d="M 103 89 Q 112 83 122 89" stroke="black" stroke-width="5" fill="none" stroke-linecap="round"/>
  <ellipse cx="88" cy="98" rx="10" ry="9" fill="white" stroke="black" stroke-width="2"/>
  <ellipse cx="112" cy="98" rx="10" ry="9" fill="white" stroke="black" stroke-width="2"/>
  <circle cx="90" cy="99" r="6" fill="${e}"/>
  <circle cx="114" cy="99" r="6" fill="${e}"/>
  <circle cx="91" cy="99" r="3" fill="black"/>
  <circle cx="115" cy="99" r="3" fill="black"/>
  <circle cx="93" cy="97" r="2" fill="white" opacity="0.9"/>
  <circle cx="117" cy="97" r="2" fill="white" opacity="0.9"/>
  <ellipse cx="100" cy="109" rx="8" ry="7" fill="#E8906A" stroke="#A85030" stroke-width="1.5"/>
  <path d="M 81 114 Q 100 128 119 114" fill="#7a0000" stroke="black" stroke-width="2"/>
  <path d="M 83 112 L 117 112 L 116 119 Q 100 126 84 119 Z" fill="white" stroke="black" stroke-width="1.5"/>
  <line x1="90" y1="112" x2="89" y2="119" stroke="#ccc" stroke-width="1.5"/>
  <line x1="100" y1="112" x2="100" y2="121" stroke="#ccc" stroke-width="1.5"/>
  <line x1="110" y1="112" x2="111" y2="119" stroke="#ccc" stroke-width="1.5"/>
  <text x="100" y="160" text-anchor="middle" fill="${p}" font-size="22" font-weight="bold" font-family="Arial Black,Arial,sans-serif">${num}</text>`;

  const scaled = scaleX !== 1
    ? `<g transform="translate(100,0) scale(${scaleX},1) translate(-100,0)">${body}</g>`
    : body;
  const inner = mirrored
    ? `<g transform="scale(-1,1) translate(-200,0)">${scaled}</g>`
    : scaled;
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 280" style="overflow:visible;width:100%;height:100%">${inner}</svg>`;
}

// ─── Character data ──────────────────────────────────────────────────────────
const CHARACTERS = [
  { name:'THE ROOKIE',       number:'97', primary:'#FF6600', secondary:'#CC3300', eyeColor:'#FFD700', scaleX:0.78,  tagline:'All talk. Limited tape time.' },
  { name:'THE VETERAN',      number:'2',  primary:'#1A237E', secondary:'#0D1257', eyeColor:'#B8860B', scaleX:1.0,   tagline:"Been here since before you were born. He'll remind you." },
  { name:"THE COACH'S SON",  number:'1',  primary:'#F9A825', secondary:'#F57F17', eyeColor:'#1565C0', scaleX:1.18,  tagline:"Doesn't need talent when dad owns the bench." },
  { name:'THE FIGURE SKATER',number:'10', primary:'#8E24AA', secondary:'#6A0080', eyeColor:'#E040FB', scaleX:0.60,  tagline:'Triple Axel. Triple threat. Triple offended.' },
  { name:'THE BEER LEAGUER', number:'69', primary:'#2E7D32', secondary:'#1B5E20', eyeColor:'#A1887F', scaleX:1.52,  tagline:'Peaked at 17. Still out here though.' },
  { name:'THE GOALIE',       number:'31', primary:'#0D1117', secondary:'#1C2A1C', eyeColor:'#00FFCC', scaleX:1.35,  tagline:'Between the pipes and beyond reason.' },
  { name:'THE EUROPEAN IMPORT',number:'19',primary:'#D32F2F',secondary:'#B71C1C',eyeColor:'#1976D2', scaleX:0.78,  tagline:'Speaks three languages. All of them devastating.' },
  { name:'THE REF',          number:'0',  primary:'#455A64', secondary:'#263238', eyeColor:'#FF6F00', scaleX:1.0,   tagline:'Off the clock. Still calling penalties.' },
];

// ─── Word bank ───────────────────────────────────────────────────────────────
const WORDS = {
  nouns: [
    [true,'your slapshot'],[true,'your wrist shot'],[true,'your five-hole'],[true,'your skating'],
    [true,'your stick handling'],[true,'your backcheck'],[true,'your glove hand'],[true,'your chirping'],
    [true,'your tape job'],[true,'your penalty shot'],[true,'your hockey sense'],[true,'your gear bag'],
    [true,'the Zamboni'],[true,'the penalty box'],[true,'your mullet'],[true,'your fighting stance'],
    [true,'that penalty'],[true,'your power play'],[false,'your teammates'],[true,'your bench'],
    [true,'a bucket of vomit'],[true,'a cream-faced loon'],[true,'a muppet'],[true,'a hamster'],
    [true,'a platypus'],[true,'Satan'],[true,'this parrot'],[true,'vodka'],
    [false,'you'],[true,'your mother'],[true,'your sister'],[true,'your father'],
    [true,'your face'],[true,'your house'],[true,'your hat'],[true,'your liver'],
    [true,'Stalin\'s jockstrap'],[true,'homeless man\'s socks'],[true,'the meaning of life'],
  ],
  verbs: [
    [true,'skate(s) like'],[true,'shoot(s) like'],[true,'dive(s) like'],[true,'chirp(s) worse than'],
    [true,'fight(s) like'],[true,'couldn\'t outskate'],[false,'belong(s) in the minors'],
    [false,'can\'t stay onside'],[false,'can\'t backcheck'],[false,'[is/are] a total pylon'],
    [false,'[is/are] softer than'],[true,'[was/were] benched by'],[true,'got(s) undressed by'],
    [true,'[is/are]'],[false,'[is/are] dull and ugly'],[false,'[is/are] minging'],
    [false,'[is/are] old'],[false,'[is/are] silly'],[false,'[is/are] worthless'],
    [true,'[was/were]'],[true,'[was/were] born in'],[true,'[was/were] defeated by'],
    [true,'act(s) like'],[true,'look(s) like'],[true,'smell(s) of'],[true,'taste(s) like'],
    [true,'dance(s) like'],[true,'farted on'],[true,'probably murdered'],
    [true,'[has/have] worse hair than'],[true,'can\'t exercise because of'],
  ],
  endings: [
    [false,'ya beauty!'],[false,'bud!'],[false,'ya donkey!'],[false,'champ!'],[false,'pal!'],
    [false,'get off the ice!'],[false,'sit down!'],[false,'go back to the minors!'],
    [false,'you plug!'],[false,'you schmuck!'],[false,'you pylon!'],[false,'you duster!'],
    [false,'and you can\'t skate!'],[false,'beauty!'],[false,'mate!'],[false,'honey!'],
    [false,'and everybody knows that!'],[false,'and I have proof!'],[false,'and piss off!'],
    [false,'cockwomble!'],[false,'you numpty!'],[false,'you pillock!'],[false,'you cheeky bastard!'],
    [false,'you inbred twit!'],[false,'you tottering fool-born hedge-pig!'],
  ],
};

// ─── Shared Button Components ────────────────────────────────────────────────
function GameButton({ children, onClick, style, size = 'md' }) {
  const [pressed, setPressed] = React.useState(false);
  const [hover, setHover] = React.useState(false);
  const sz = size === 'lg' ? { fontSize: 11, padding: '14px 56px', letterSpacing: 4 } : { fontSize: 10, padding: '12px 26px', letterSpacing: 2 };
  return (
    <button onClick={onClick}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      onMouseDown={() => setPressed(true)} onMouseUp={() => setPressed(false)}
      style={{
        fontFamily: "'Press Start 2P', monospace", fontSize: sz.fontSize, background: '#001c00',
        color: '#00ff88', cursor: 'pointer', borderRadius: 0, padding: sz.padding,
        letterSpacing: sz.letterSpacing, textTransform: 'uppercase',
        textShadow: '0 0 10px rgba(0,255,136,0.8)',
        borderTop: `3px solid ${pressed ? '#005522' : '#00ee66'}`,
        borderLeft: `3px solid ${pressed ? '#005522' : '#00ee66'}`,
        borderRight: `3px solid ${pressed ? '#00ee66' : '#005522'}`,
        borderBottom: `3px solid ${pressed ? '#00ee66' : '#005522'}`,
        boxShadow: hover && !pressed ? '0 0 24px rgba(0,220,100,0.3)' : '0 0 14px rgba(0,180,80,0.15)',
        filter: hover && !pressed ? 'brightness(1.15)' : 'none',
        transform: pressed ? 'translate(2px,2px)' : 'none',
        transition: 'filter 0.08s, transform 0.08s',
        ...style
      }}>
      {children}
    </button>
  );
}

function SecondaryButton({ children, onClick, style }) {
  const [pressed, setPressed] = React.useState(false);
  const [hover, setHover] = React.useState(false);
  return (
    <button onClick={onClick}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      onMouseDown={() => setPressed(true)} onMouseUp={() => setPressed(false)}
      style={{
        fontFamily: "'Press Start 2P', monospace", fontSize: 10, background: '#0c1220',
        color: '#7799bb', cursor: 'pointer', borderRadius: 0, padding: '12px 26px',
        letterSpacing: 2, textTransform: 'uppercase',
        borderTop: `3px solid ${pressed ? '#111e33' : '#4466aa'}`,
        borderLeft: `3px solid ${pressed ? '#111e33' : '#4466aa'}`,
        borderRight: `3px solid ${pressed ? '#4466aa' : '#111e33'}`,
        borderBottom: `3px solid ${pressed ? '#4466aa' : '#111e33'}`,
        filter: hover ? 'brightness(1.2)' : 'none',
        transform: pressed ? 'translate(2px,2px)' : 'none',
        transition: 'filter 0.08s, transform 0.08s',
        ...style
      }}>
      {children}
    </button>
  );
}

// ─── Export ──────────────────────────────────────────────────────────────────
Object.assign(window, { makeCharSVG, CHARACTERS, WORDS, GameButton, SecondaryButton });
